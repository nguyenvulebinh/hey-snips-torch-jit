class LinearSubsampling1(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  subsampling_rate : int
  out : __torch__.torch.nn.modules.container.Sequential
  quant : __torch__.torch.ao.quantization.stubs.QuantStub
  dequant : __torch__.torch.ao.quantization.stubs.DeQuantStub
  def forward(self: __torch__.wekws.model.subsampling.LinearSubsampling1,
    x: Tensor) -> Tensor:
    quant = self.quant
    x0 = (quant).forward(x, )
    out = self.out
    x1 = (out).forward(x0, )
    dequant = self.dequant
    return (dequant).forward(x1, )
