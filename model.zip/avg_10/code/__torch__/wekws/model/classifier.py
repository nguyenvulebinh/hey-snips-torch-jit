class LinearClassifier(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  linear : __torch__.torch.nn.modules.linear.___torch_mangle_11.Linear
  quant : __torch__.torch.ao.quantization.stubs.QuantStub
  dequant : __torch__.torch.ao.quantization.stubs.DeQuantStub
  def forward(self: __torch__.wekws.model.classifier.LinearClassifier,
    x: Tensor) -> Tensor:
    quant = self.quant
    x0 = (quant).forward(x, )
    linear = self.linear
    x1 = (linear).forward(x0, )
    dequant = self.dequant
    return (dequant).forward(x1, )
