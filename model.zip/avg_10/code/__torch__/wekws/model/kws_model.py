class KWSModel(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  idim : int
  odim : int
  hdim : int
  global_cmvn : __torch__.wekws.model.cmvn.GlobalCMVN
  preprocessing : __torch__.wekws.model.subsampling.LinearSubsampling1
  backbone : __torch__.wekws.model.mdtc.MDTC
  classifier : __torch__.wekws.model.classifier.LinearClassifier
  activation : __torch__.torch.nn.modules.activation.Sigmoid
  def forward(self: __torch__.wekws.model.kws_model.KWSModel,
    x: Tensor,
    in_cache: Tensor=CONSTANTS.c0) -> Tuple[Tensor, Tensor]:
    global_cmvn = self.global_cmvn
    x0 = (global_cmvn).forward(x, )
    preprocessing = self.preprocessing
    x1 = (preprocessing).forward(x0, )
    backbone = self.backbone
    x2, out_cache, = (backbone).forward(x1, in_cache, )
    classifier = self.classifier
    x3 = (classifier).forward(x2, )
    activation = self.activation
    x4 = (activation).forward(x3, )
    return (x4, out_cache)
