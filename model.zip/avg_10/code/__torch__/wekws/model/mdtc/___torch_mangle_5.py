class DSDilatedConv1d(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  padding : int
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_4.Conv1d
  bn : __torch__.torch.nn.modules.batchnorm.BatchNorm1d
  pointwise : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv1d
  def forward(self: __torch__.wekws.model.mdtc.___torch_mangle_5.DSDilatedConv1d,
    inputs: Tensor) -> Tensor:
    conv = self.conv
    outputs = (conv).forward(inputs, )
    bn = self.bn
    outputs0 = (bn).forward(outputs, )
    pointwise = self.pointwise
    return (pointwise).forward(outputs0, )
