class TCNBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  in_channels : int
  res_channels : int
  kernel_size : int
  dilation : int
  causal : bool
  padding : int
  half_padding : int
  conv1 : __torch__.wekws.model.mdtc.___torch_mangle_8.DSDilatedConv1d
  bn1 : __torch__.torch.nn.modules.batchnorm.BatchNorm1d
  relu1 : __torch__.torch.nn.modules.activation.ReLU
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv1d
  bn2 : __torch__.torch.nn.modules.batchnorm.BatchNorm1d
  relu2 : __torch__.torch.nn.modules.activation.ReLU
  def forward(self: __torch__.wekws.model.mdtc.___torch_mangle_9.TCNBlock,
    inputs: Tensor,
    cache: Tensor=CONSTANTS.c0) -> Tuple[Tensor, Tensor]:
    if torch.eq(torch.size(cache, 0), 0):
      padding = self.padding
      outputs0 = torch.pad(inputs, [padding, 0], "constant", 0.)
      outputs = outputs0
    else:
      outputs = torch.cat([cache, inputs], 2)
    _0 = torch.size(outputs, 2)
    padding0 = self.padding
    if torch.gt(_0, padding0):
      pass
    else:
      ops.prim.RaiseException("AssertionError: ")
    _1 = torch.slice(torch.slice(outputs), 1)
    padding1 = self.padding
    new_cache = torch.slice(_1, 2, torch.neg(padding1))
    relu1 = self.relu1
    bn1 = self.bn1
    conv1 = self.conv1
    _2 = (bn1).forward((conv1).forward(outputs, ), )
    outputs1 = (relu1).forward(_2, )
    bn2 = self.bn2
    conv2 = self.conv2
    outputs2 = (bn2).forward((conv2).forward(outputs1, ), )
    in_channels = self.in_channels
    res_channels = self.res_channels
    if torch.eq(in_channels, res_channels):
      relu2 = self.relu2
      res_out0 = (relu2).forward(torch.add(outputs2, inputs), )
      res_out = res_out0
    else:
      relu20 = self.relu2
      res_out = (relu20).forward(outputs2, )
    return (res_out, new_cache)
