class MDTC(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  kernel_size : int
  causal : bool
  padding : int
  half_padding : int
  preprocessor : __torch__.wekws.model.mdtc.TCNBlock
  relu : __torch__.torch.nn.modules.activation.ReLU
  blocks : __torch__.torch.nn.modules.container.___torch_mangle_10.ModuleList
  def forward(self: __torch__.wekws.model.mdtc.MDTC,
    x: Tensor,
    in_cache: Tensor=CONSTANTS.c0) -> Tuple[Tensor, Tensor]:
    outputs = torch.transpose(x, 1, 2)
    _0 = annotate(List[Tensor], [])
    _1 = annotate(List[Tensor], [])
    _2 = torch.gt(torch.size(in_cache, 0), 0)
    if _2:
      _3 = torch.slice(torch.slice(in_cache), 1)
      preprocessor = self.preprocessor
      padding = preprocessor.padding
      c_in0 = torch.slice(_3, 2, 0, torch.add(0, padding))
      c_in = c_in0
    else:
      c_in = torch.zeros([0, 0, 0])
    preprocessor0 = self.preprocessor
    _4 = (preprocessor0).forward(outputs, c_in, )
    outputs0, c_out, = _4
    relu = self.relu
    outputs1 = (relu).forward(outputs0, )
    _5 = torch.append(_1, c_out)
    preprocessor1 = self.preprocessor
    padding0 = preprocessor1.padding
    offset = torch.add(0, padding0)
    blocks = self.blocks
    _00 = getattr(blocks, "0")
    _10 = getattr(blocks, "1")
    _20 = getattr(blocks, "2")
    _6 = torch.gt(torch.size(in_cache, 0), 0)
    if _6:
      _7 = torch.slice(torch.slice(in_cache), 1)
      padding1 = _00.padding
      c_in2 = torch.slice(_7, 2, offset, torch.add(offset, padding1))
      c_in1 = c_in2
    else:
      c_in1 = torch.zeros([0, 0, 0])
    outputs2, c_out0, = (_00).forward(outputs1, c_in1, )
    _8 = torch.append(_0, outputs2)
    _9 = torch.append(_1, c_out0)
    padding2 = _00.padding
    offset0 = torch.add(offset, padding2)
    _11 = torch.gt(torch.size(in_cache, 0), 0)
    if _11:
      _12 = torch.slice(torch.slice(in_cache), 1)
      padding3 = _10.padding
      c_in4 = torch.slice(_12, 2, offset0, torch.add(offset0, padding3))
      c_in3 = c_in4
    else:
      c_in3 = torch.zeros([0, 0, 0])
    outputs3, c_out1, = (_10).forward(outputs2, c_in3, )
    _13 = torch.append(_0, outputs3)
    _14 = torch.append(_1, c_out1)
    padding4 = _10.padding
    offset1 = torch.add(offset0, padding4)
    _15 = torch.gt(torch.size(in_cache, 0), 0)
    if _15:
      _16 = torch.slice(torch.slice(in_cache), 1)
      padding5 = _20.padding
      c_in6 = torch.slice(_16, 2, offset1, torch.add(offset1, padding5))
      c_in5 = c_in6
    else:
      c_in5 = torch.zeros([0, 0, 0])
    outputs4, c_out2, = (_20).forward(outputs3, c_in5, )
    _17 = torch.append(_0, outputs4)
    _18 = torch.append(_1, c_out2)
    outputs5 = torch.zeros_like(_0[-1], dtype=ops.prim.dtype(_0[-1]))
    outputs6 = outputs5
    for _19 in range(torch.len(_0)):
      x0 = _0[_19]
      outputs6 = torch.add_(outputs6, x0)
    outputs7 = torch.transpose(outputs6, 1, 2)
    new_cache = torch.cat(_1, 2)
    return (outputs7, new_cache)
class TCNBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  in_channels : int
  res_channels : int
  kernel_size : int
  dilation : int
  causal : bool
  padding : int
  half_padding : int
  conv1 : __torch__.wekws.model.mdtc.DSDilatedConv1d
  bn1 : __torch__.torch.nn.modules.batchnorm.BatchNorm1d
  relu1 : __torch__.torch.nn.modules.activation.ReLU
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv1d
  bn2 : __torch__.torch.nn.modules.batchnorm.BatchNorm1d
  relu2 : __torch__.torch.nn.modules.activation.ReLU
  def forward(self: __torch__.wekws.model.mdtc.TCNBlock,
    inputs: Tensor,
    cache: Tensor=CONSTANTS.c0) -> Tuple[Tensor, Tensor]:
    if torch.eq(torch.size(cache, 0), 0):
      padding = self.padding
      outputs8 = torch.pad(inputs, [padding, 0], "constant", 0.)
      outputs = outputs8
    else:
      outputs = torch.cat([cache, inputs], 2)
    _19 = torch.size(outputs, 2)
    padding6 = self.padding
    if torch.gt(_19, padding6):
      pass
    else:
      ops.prim.RaiseException("AssertionError: ")
    _20 = torch.slice(torch.slice(outputs), 1)
    padding7 = self.padding
    new_cache = torch.slice(_20, 2, torch.neg(padding7))
    relu1 = self.relu1
    bn1 = self.bn1
    conv1 = self.conv1
    _21 = (bn1).forward((conv1).forward(outputs, ), )
    outputs9 = (relu1).forward(_21, )
    bn2 = self.bn2
    conv2 = self.conv2
    outputs10 = (bn2).forward((conv2).forward(outputs9, ), )
    in_channels = self.in_channels
    res_channels = self.res_channels
    if torch.eq(in_channels, res_channels):
      relu2 = self.relu2
      res_out0 = (relu2).forward(torch.add(outputs10, inputs), )
      res_out = res_out0
    else:
      relu20 = self.relu2
      res_out = (relu20).forward(outputs10, )
    return (res_out, new_cache)
class DSDilatedConv1d(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  padding : int
  conv : __torch__.torch.nn.modules.conv.Conv1d
  bn : __torch__.torch.nn.modules.batchnorm.BatchNorm1d
  pointwise : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv1d
  def forward(self: __torch__.wekws.model.mdtc.DSDilatedConv1d,
    inputs: Tensor) -> Tensor:
    conv = self.conv
    outputs = (conv).forward(inputs, )
    bn = self.bn
    outputs11 = (bn).forward(outputs, )
    pointwise = self.pointwise
    return (pointwise).forward(outputs11, )
class TCNStack(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  in_channels : int
  stack_num : int
  stack_size : int
  res_channels : int
  kernel_size : int
  causal : bool
  padding : int
  res_blocks : __torch__.torch.nn.modules.container.ModuleList
  def forward(self: __torch__.wekws.model.mdtc.TCNStack,
    inputs: Tensor,
    in_cache: Tensor=CONSTANTS.c0) -> Tuple[Tensor, Tensor]:
    _22 = annotate(List[Tensor], [])
    res_blocks = self.res_blocks
    _0 = getattr(res_blocks, "0")
    _1 = getattr(res_blocks, "1")
    _2 = getattr(res_blocks, "2")
    _3 = getattr(res_blocks, "3")
    _23 = torch.gt(torch.size(in_cache, 0), 0)
    if _23:
      _24 = torch.slice(torch.slice(in_cache), 1)
      padding = _0.padding
      c_in7 = torch.slice(_24, 2, 0, torch.add(0, padding))
      c_in = c_in7
    else:
      c_in = torch.zeros([0, 0, 0])
    outputs, c_out, = (_0).forward(inputs, c_in, )
    _25 = torch.append(_22, c_out)
    padding8 = _0.padding
    offset = torch.add(0, padding8)
    _26 = torch.gt(torch.size(in_cache, 0), 0)
    if _26:
      _27 = torch.slice(torch.slice(in_cache), 1)
      padding9 = _1.padding
      c_in9 = torch.slice(_27, 2, offset, torch.add(offset, padding9))
      c_in8 = c_in9
    else:
      c_in8 = torch.zeros([0, 0, 0])
    outputs12, c_out3, = (_1).forward(outputs, c_in8, )
    _28 = torch.append(_22, c_out3)
    padding10 = _1.padding
    offset2 = torch.add(offset, padding10)
    _29 = torch.gt(torch.size(in_cache, 0), 0)
    if _29:
      _30 = torch.slice(torch.slice(in_cache), 1)
      padding11 = _2.padding
      c_in11 = torch.slice(_30, 2, offset2, torch.add(offset2, padding11))
      c_in10 = c_in11
    else:
      c_in10 = torch.zeros([0, 0, 0])
    outputs13, c_out4, = (_2).forward(outputs12, c_in10, )
    _31 = torch.append(_22, c_out4)
    padding12 = _2.padding
    offset3 = torch.add(offset2, padding12)
    _32 = torch.gt(torch.size(in_cache, 0), 0)
    if _32:
      _33 = torch.slice(torch.slice(in_cache), 1)
      padding13 = _3.padding
      c_in13 = torch.slice(_33, 2, offset3, torch.add(offset3, padding13))
      c_in12 = c_in13
    else:
      c_in12 = torch.zeros([0, 0, 0])
    outputs14, c_out5, = (_3).forward(outputs13, c_in12, )
    _34 = torch.append(_22, c_out5)
    new_cache = torch.cat(_22, 2)
    return (outputs14, new_cache)
