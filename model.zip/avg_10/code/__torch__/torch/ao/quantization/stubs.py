class QuantStub(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.ao.quantization.stubs.QuantStub,
    x: Tensor) -> Tensor:
    return x
class DeQuantStub(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.ao.quantization.stubs.DeQuantStub,
    x: Tensor) -> Tensor:
    return x
