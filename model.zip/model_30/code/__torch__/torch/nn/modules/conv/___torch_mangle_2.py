class Conv1d(Module):
  __parameters__ = ["weight", "bias", ]
  __buffers__ = []
  weight : Tensor
  bias : Optional[Tensor]
  training : bool
  _is_full_backward_hook : NoneType
  transposed : bool
  _reversed_padding_repeated_twice : List[int]
  stride : Final[Tuple[int]] = (1,)
  dilation : Final[Tuple[int]] = (2,)
  padding : Final[Tuple[int]] = (0,)
  in_channels : Final[int] = 256
  kernel_size : Final[Tuple[int]] = (8,)
  output_padding : Final[Tuple[int]] = (0,)
  padding_mode : Final[str] = "zeros"
  groups : Final[int] = 256
  out_channels : Final[int] = 256
  def forward(self: __torch__.torch.nn.modules.conv.___torch_mangle_2.Conv1d,
    input: Tensor) -> Tensor:
    weight = self.weight
    bias = self.bias
    _0 = (self)._conv_forward(input, weight, bias, )
    return _0
  def _conv_forward(self: __torch__.torch.nn.modules.conv.___torch_mangle_2.Conv1d,
    input: Tensor,
    weight: Tensor,
    bias: Optional[Tensor]) -> Tensor:
    _1 = torch.conv1d(input, weight, bias, [1], [0], [2], 256)
    return _1
