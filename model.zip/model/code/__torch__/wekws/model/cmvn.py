class GlobalCMVN(Module):
  __parameters__ = []
  __buffers__ = ["mean", "istd", ]
  mean : Tensor
  istd : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  norm_var : bool
  def forward(self: __torch__.wekws.model.cmvn.GlobalCMVN,
    x: Tensor) -> Tensor:
    mean = self.mean
    x0 = torch.sub(x, mean)
    norm_var = self.norm_var
    if norm_var:
      istd = self.istd
      x1 = torch.mul(x0, istd)
    else:
      x1 = x0
    return x1
