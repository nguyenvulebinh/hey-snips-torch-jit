class TCN(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  padding : int
  network : __torch__.torch.nn.modules.container.ModuleList
  def forward(self: __torch__.wekws.model.tcn.TCN,
    x: Tensor,
    in_cache: Tensor=CONSTANTS.c0) -> Tuple[Tensor, Tensor]:
    x0 = torch.transpose(x, 1, 2)
    _0 = annotate(List[Tensor], [])
    network = self.network
    _00 = getattr(network, "0")
    _1 = getattr(network, "1")
    _2 = getattr(network, "2")
    _3 = getattr(network, "3")
    _4 = torch.gt(torch.size(in_cache, 0), 0)
    if _4:
      _5 = torch.slice(torch.slice(in_cache), 1)
      padding = _00.padding
      c_in0 = torch.slice(_5, 2, 0, torch.add(0, padding))
      c_in = c_in0
    else:
      c_in = torch.zeros([0, 0, 0])
    x1, c_out, = (_00).forward(x0, c_in, )
    _6 = torch.append(_0, c_out)
    padding0 = _00.padding
    offset = torch.add(0, padding0)
    _7 = torch.gt(torch.size(in_cache, 0), 0)
    if _7:
      _8 = torch.slice(torch.slice(in_cache), 1)
      padding1 = _1.padding
      c_in2 = torch.slice(_8, 2, offset, torch.add(offset, padding1))
      c_in1 = c_in2
    else:
      c_in1 = torch.zeros([0, 0, 0])
    x2, c_out0, = (_1).forward(x1, c_in1, )
    _9 = torch.append(_0, c_out0)
    padding2 = _1.padding
    offset0 = torch.add(offset, padding2)
    _10 = torch.gt(torch.size(in_cache, 0), 0)
    if _10:
      _11 = torch.slice(torch.slice(in_cache), 1)
      padding3 = _2.padding
      c_in4 = torch.slice(_11, 2, offset0, torch.add(offset0, padding3))
      c_in3 = c_in4
    else:
      c_in3 = torch.zeros([0, 0, 0])
    x3, c_out1, = (_2).forward(x2, c_in3, )
    _12 = torch.append(_0, c_out1)
    padding4 = _2.padding
    offset1 = torch.add(offset0, padding4)
    _13 = torch.gt(torch.size(in_cache, 0), 0)
    if _13:
      _14 = torch.slice(torch.slice(in_cache), 1)
      padding5 = _3.padding
      c_in6 = torch.slice(_14, 2, offset1, torch.add(offset1, padding5))
      c_in5 = c_in6
    else:
      c_in5 = torch.zeros([0, 0, 0])
    x4, c_out2, = (_3).forward(x3, c_in5, )
    _15 = torch.append(_0, c_out2)
    x5 = torch.transpose(x4, 1, 2)
    new_cache = torch.cat(_0, 2)
    return (x5, new_cache)
class DsCnnBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  padding : int
  quant : __torch__.torch.ao.quantization.stubs.QuantStub
  dequant : __torch__.torch.ao.quantization.stubs.DeQuantStub
  cnn : __torch__.torch.nn.modules.container.___torch_mangle_1.Sequential
  def forward(self: __torch__.wekws.model.tcn.DsCnnBlock,
    x: Tensor,
    cache: Tensor=CONSTANTS.c0) -> Tuple[Tensor, Tensor]:
    if torch.eq(torch.size(cache, 0), 0):
      padding = self.padding
      y0 = __torch__.torch.nn.functional.pad(x, [padding, 0], "constant", 0., )
      y = y0
    else:
      y = torch.cat([cache, x], 2)
    _13 = torch.size(y, 2)
    padding6 = self.padding
    if torch.gt(_13, padding6):
      pass
    else:
      ops.prim.RaiseException("AssertionError: ")
    _14 = torch.slice(torch.slice(y), 1)
    padding7 = self.padding
    new_cache = torch.slice(_14, 2, torch.neg(padding7))
    quant = self.quant
    y1 = (quant).forward(y, )
    cnn = self.cnn
    y2 = (cnn).forward(y1, )
    dequant = self.dequant
    y3 = (dequant).forward(y2, )
    y4 = torch.add(y3, x)
    return (y4, new_cache)
