class DsCnnBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  padding : int
  quant : __torch__.torch.ao.quantization.stubs.QuantStub
  dequant : __torch__.torch.ao.quantization.stubs.DeQuantStub
  cnn : __torch__.torch.nn.modules.container.___torch_mangle_3.Sequential
  def forward(self: __torch__.wekws.model.tcn.___torch_mangle_4.DsCnnBlock,
    x: Tensor,
    cache: Tensor=CONSTANTS.c0) -> Tuple[Tensor, Tensor]:
    if torch.eq(torch.size(cache, 0), 0):
      padding = self.padding
      y0 = __torch__.torch.nn.functional.pad(x, [padding, 0], "constant", 0., )
      y = y0
    else:
      y = torch.cat([cache, x], 2)
    _0 = torch.size(y, 2)
    padding0 = self.padding
    if torch.gt(_0, padding0):
      pass
    else:
      ops.prim.RaiseException("AssertionError: ")
    _1 = torch.slice(torch.slice(y), 1)
    padding1 = self.padding
    new_cache = torch.slice(_1, 2, torch.neg(padding1))
    quant = self.quant
    y1 = (quant).forward(y, )
    cnn = self.cnn
    y2 = (cnn).forward(y1, )
    dequant = self.dequant
    y3 = (dequant).forward(y2, )
    y4 = torch.add(y3, x)
    return (y4, new_cache)
